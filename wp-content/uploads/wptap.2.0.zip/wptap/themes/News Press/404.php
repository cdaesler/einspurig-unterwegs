<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header();
?>

	<div class="narrowcolumn">

	</div>

<?php get_footer(); ?>